#ifndef STUDENT_STUDENT_H
#define STUDENT_STUDENT_H

#include "gradebook.h"

typedef struct Student{
    GradeBook* gradeBook;
};

#endif