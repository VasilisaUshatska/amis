#include "student.h"
#include "choosedanswer.h"
#include "examticket.h"
#include "gradebook.h"
#include "work.h"
#include "task.h"

int main() {
    return 0;
}